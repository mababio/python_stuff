# Download the Python helper library from twilio.com/docs/python/install
from twilio.rest import Client
import argparse


# Your Account Sid and Auth Token from twilio.com/user/account
account_sid = "ACee89a17cae64509e882c10346e0b5383"
auth_token = "2cb6371ce7895e94d3a45fedacb39e6f"
client = Client(account_sid, auth_token)







def get_name(phone_num): 
	client_obj =  client.lookups.phone_numbers("+1"+ phone_num).fetch(type="caller-name", )
	return client_obj.caller_name['caller_name']



def main():

	parser =  argparse.ArgumentParser()
	parser.add_argument("num", help=" 7 digit phone number", type=int)
	args = parser.parse_args()
	val  = get_name(str(args.num))	
	print(val)

if __name__ =="__main__":
	#print('hello working')
	main()
